import { Card } from "@/components/ui/card"
import {
  BarChart,
  Bar,
  LineChart,
  Line,
  PieChart,
  Pie,
  Cell,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
} from "recharts"

const economicData = [
  { country: "Indonesia", loss: 4500, percentage: 30 },
  { country: "Thailand", loss: 3000, percentage: 20 },
  { country: "Sri Lanka", loss: 2800, percentage: 18.7 },
  { country: "India", loss: 2200, percentage: 14.7 },
  { country: "Somalia", loss: 1000, percentage: 6.7 },
  { country: "Others", loss: 1500, percentage: 10 },
]

const sectorData = [
  { name: "Fishing & Aquaculture", value: 4200, color: "var(--color-chart-1)" },
  { name: "Tourism", value: 3800, color: "var(--color-chart-2)" },
  { name: "Infrastructure", value: 3500, color: "var(--color-chart-3)" },
  { name: "Agriculture", value: 2100, color: "var(--color-chart-4)" },
  { name: "Other", value: 1400, color: "var(--color-chart-5)" },
]

const recoveryTimeline = [
  { year: 2004, reconstruction: 0, recovery: 10 },
  { year: 2005, reconstruction: 2000, recovery: 25 },
  { year: 2006, reconstruction: 3500, recovery: 40 },
  { year: 2007, reconstruction: 4200, recovery: 55 },
  { year: 2008, reconstruction: 4800, recovery: 65 },
  { year: 2009, reconstruction: 5200, recovery: 75 },
  { year: 2010, reconstruction: 5500, recovery: 85 },
]

export default function Dashboard() {
  return (
    <main className="min-h-screen bg-background">
      {/* Header */}
      <div className="bg-primary text-primary-foreground py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h1 className="text-4xl md:text-5xl font-bold mb-4">Economic Impact Dashboard</h1>
          <p className="text-lg opacity-90">Comprehensive analysis of the 2004 tsunami's economic consequences</p>
        </div>
      </div>

      {/* Main Content */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        {/* Key Metrics */}
        <div className="grid md:grid-cols-4 gap-6 mb-12">
          <Card className="p-6">
            <p className="text-muted-foreground text-sm mb-2">Total Economic Loss</p>
            <p className="text-3xl font-bold text-primary">$15B</p>
            <p className="text-xs text-muted-foreground mt-2">USD equivalent</p>
          </Card>
          <Card className="p-6">
            <p className="text-muted-foreground text-sm mb-2">Affected Population</p>
            <p className="text-3xl font-bold text-accent">5M+</p>
            <p className="text-xs text-muted-foreground mt-2">People impacted</p>
          </Card>
          <Card className="p-6">
            <p className="text-muted-foreground text-sm mb-2">Recovery Period</p>
            <p className="text-3xl font-bold text-secondary">5-10 Years</p>
            <p className="text-xs text-muted-foreground mt-2">Average timeline</p>
          </Card>
          <Card className="p-6">
            <p className="text-muted-foreground text-sm mb-2">Countries Affected</p>
            <p className="text-3xl font-bold">14</p>
            <p className="text-xs text-muted-foreground mt-2">Across 3 continents</p>
          </Card>
        </div>

        {/* Charts Section */}
        <div className="grid lg:grid-cols-2 gap-8 mb-12">
          {/* Economic Loss by Country */}
          <Card className="p-6">
            <h2 className="text-2xl font-bold mb-6">Economic Loss by Country ($ Millions)</h2>
            <ResponsiveContainer width="100%" height={300}>
              <BarChart data={economicData}>
                <CartesianGrid strokeDasharray="3 3" stroke="var(--color-border)" />
                <XAxis dataKey="country" stroke="var(--color-muted-foreground)" />
                <YAxis stroke="var(--color-muted-foreground)" />
                <Tooltip
                  contentStyle={{
                    backgroundColor: "var(--color-card)",
                    border: "1px solid var(--color-border)",
                    borderRadius: "var(--radius)",
                  }}
                  formatter={(value) => `$${value}M`}
                />
                <Bar dataKey="loss" fill="var(--color-primary)" radius={[8, 8, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </Card>

          {/* Sector Impact */}
          <Card className="p-6">
            <h2 className="text-2xl font-bold mb-6">Economic Impact by Sector ($ Millions)</h2>
            <ResponsiveContainer width="100%" height={300}>
              <PieChart>
                <Pie
                  data={sectorData}
                  cx="50%"
                  cy="50%"
                  labelLine={false}
                  label={({ name, value }) => `${name}: $${value}M`}
                  outerRadius={80}
                  fill="#8884d8"
                  dataKey="value"
                >
                  {sectorData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Pie>
                <Tooltip formatter={(value) => `$${value}M`} />
              </PieChart>
            </ResponsiveContainer>
          </Card>
        </div>

        {/* Recovery Timeline */}
        <Card className="p-6 mb-12">
          <h2 className="text-2xl font-bold mb-6">Reconstruction & Recovery Progress (2004-2010)</h2>
          <ResponsiveContainer width="100%" height={350}>
            <LineChart data={recoveryTimeline}>
              <CartesianGrid strokeDasharray="3 3" stroke="var(--color-border)" />
              <XAxis dataKey="year" stroke="var(--color-muted-foreground)" />
              <YAxis stroke="var(--color-muted-foreground)" />
              <Tooltip
                contentStyle={{
                  backgroundColor: "var(--color-card)",
                  border: "1px solid var(--color-border)",
                  borderRadius: "var(--radius)",
                }}
                formatter={(value) => `$${value}M`}
              />
              <Legend />
              <Line
                type="monotone"
                dataKey="reconstruction"
                stroke="var(--color-primary)"
                strokeWidth={2}
                name="Reconstruction Spending"
                dot={{ fill: "var(--color-primary)", r: 4 }}
              />
              <Line
                type="monotone"
                dataKey="recovery"
                stroke="var(--color-accent)"
                strokeWidth={2}
                name="Recovery Progress (%)"
                dot={{ fill: "var(--color-accent)", r: 4 }}
              />
            </LineChart>
          </ResponsiveContainer>
        </Card>

        {/* Detailed Breakdown */}
        <div className="grid md:grid-cols-2 gap-8">
          <Card className="p-6">
            <h3 className="text-xl font-bold mb-4">Infrastructure Damage</h3>
            <ul className="space-y-3">
              <li className="flex justify-between items-center pb-3 border-b border-border">
                <span className="text-muted-foreground">Coastal Roads & Bridges</span>
                <span className="font-semibold">$2.1B</span>
              </li>
              <li className="flex justify-between items-center pb-3 border-b border-border">
                <span className="text-muted-foreground">Housing & Buildings</span>
                <span className="font-semibold">$1.8B</span>
              </li>
              <li className="flex justify-between items-center pb-3 border-b border-border">
                <span className="text-muted-foreground">Ports & Harbors</span>
                <span className="font-semibold">$1.2B</span>
              </li>
              <li className="flex justify-between items-center pb-3 border-b border-border">
                <span className="text-muted-foreground">Water & Sanitation</span>
                <span className="font-semibold">$0.8B</span>
              </li>
              <li className="flex justify-between items-center pt-3">
                <span className="font-bold">Total Infrastructure</span>
                <span className="font-bold text-primary">$5.9B</span>
              </li>
            </ul>
          </Card>

          <Card className="p-6">
            <h3 className="text-xl font-bold mb-4">Livelihood & Economic Sectors</h3>
            <ul className="space-y-3">
              <li className="flex justify-between items-center pb-3 border-b border-border">
                <span className="text-muted-foreground">Fishing Industry</span>
                <span className="font-semibold">$2.8B</span>
              </li>
              <li className="flex justify-between items-center pb-3 border-b border-border">
                <span className="text-muted-foreground">Tourism Sector</span>
                <span className="font-semibold">$2.4B</span>
              </li>
              <li className="flex justify-between items-center pb-3 border-b border-border">
                <span className="text-muted-foreground">Agriculture</span>
                <span className="font-semibold">$1.6B</span>
              </li>
              <li className="flex justify-between items-center pb-3 border-b border-border">
                <span className="text-muted-foreground">Manufacturing</span>
                <span className="font-semibold">$0.9B</span>
              </li>
              <li className="flex justify-between items-center pt-3">
                <span className="font-bold">Total Livelihoods</span>
                <span className="font-bold text-accent">$7.7B</span>
              </li>
            </ul>
          </Card>
        </div>
      </div>
    </main>
  )
}
