"use client"

import { useState } from "react"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { MapPin, Users, TrendingDown, Clock } from "lucide-react"

const countries = [
  {
    id: "indonesia",
    name: "Indonesia",
    flag: "🇮🇩",
    region: "Southeast Asia",
    deathToll: 167000,
    economicLoss: 4500,
    affectedPopulation: 1200000,
    recoveryYears: 7,
    description:
      "Indonesia was the hardest hit country, with Aceh province suffering catastrophic damage. The tsunami waves reached heights of up to 100 feet in some areas.",
    impact: {
      infrastructure: "Entire coastal cities destroyed, ports severely damaged",
      economy: "Fishing industry devastated, tourism collapsed temporarily",
      population: "Largest death toll, massive displacement of survivors",
      recovery: "Took 7+ years for full economic recovery",
    },
    keyStats: [
      { label: "Deaths", value: "167,000" },
      { label: "Displaced", value: "500,000+" },
      { label: "Economic Loss", value: "$4.5B" },
      { label: "Recovery Time", value: "7+ years" },
    ],
  },
  {
    id: "thailand",
    name: "Thailand",
    flag: "🇹🇭",
    region: "Southeast Asia",
    deathToll: 5400,
    economicLoss: 3000,
    affectedPopulation: 800000,
    recoveryYears: 5,
    description:
      "Thailand's tourist destinations like Phuket and Krabi were severely impacted. The tsunami disrupted the tourism industry, which is vital to the Thai economy.",
    impact: {
      infrastructure: "Beach resorts and hotels destroyed, roads and bridges damaged",
      economy: "Tourism sector collapsed, fishing communities devastated",
      population: "Many foreign tourists among the casualties",
      recovery: "Tourism recovered within 3-4 years with international support",
    },
    keyStats: [
      { label: "Deaths", value: "5,400" },
      { label: "Displaced", value: "200,000+" },
      { label: "Economic Loss", value: "$3.0B" },
      { label: "Recovery Time", value: "5 years" },
    ],
  },
  {
    id: "srilanka",
    name: "Sri Lanka",
    flag: "🇱🇰",
    region: "South Asia",
    deathToll: 35000,
    economicLoss: 2800,
    affectedPopulation: 900000,
    recoveryYears: 6,
    description:
      "Sri Lanka's entire coastline was affected, with the southern and eastern coasts experiencing the most severe damage. The disaster impacted the country's tea and fishing industries.",
    impact: {
      infrastructure: "Coastal railway destroyed, ports damaged, housing destroyed",
      economy: "Tea exports disrupted, fishing fleet lost, tourism halted",
      population: "Significant casualties, widespread homelessness",
      recovery: "Gradual recovery with focus on rebuilding coastal infrastructure",
    },
    keyStats: [
      { label: "Deaths", value: "35,000" },
      { label: "Displaced", value: "300,000+" },
      { label: "Economic Loss", value: "$2.8B" },
      { label: "Recovery Time", value: "6 years" },
    ],
  },
  {
    id: "india",
    name: "India",
    flag: "🇮🇳",
    region: "South Asia",
    deathToll: 16000,
    economicLoss: 2200,
    affectedPopulation: 600000,
    recoveryYears: 5,
    description:
      "India's southern coast, particularly Tamil Nadu and Andhra Pradesh, suffered significant damage. The tsunami affected fishing communities and coastal agriculture.",
    impact: {
      infrastructure: "Coastal villages destroyed, fishing ports damaged",
      economy: "Fishing industry disrupted, agricultural lands affected",
      population: "Primarily affected fishing communities and coastal residents",
      recovery: "Focused on rebuilding fishing infrastructure and coastal protection",
    },
    keyStats: [
      { label: "Deaths", value: "16,000" },
      { label: "Displaced", value: "250,000+" },
      { label: "Economic Loss", value: "$2.2B" },
      { label: "Recovery Time", value: "5 years" },
    ],
  },
  {
    id: "somalia",
    name: "Somalia",
    flag: "🇸🇴",
    region: "East Africa",
    deathToll: 300,
    economicLoss: 1000,
    affectedPopulation: 200000,
    recoveryYears: 4,
    description:
      "Somalia's eastern coast was impacted despite being thousands of miles away. The disaster compounded existing humanitarian challenges in the country.",
    impact: {
      infrastructure: "Coastal settlements damaged, limited infrastructure affected",
      economy: "Fishing communities disrupted, limited economic impact",
      population: "Relatively lower casualties due to lower population density",
      recovery: "Slower recovery due to existing political instability",
    },
    keyStats: [
      { label: "Deaths", value: "300" },
      { label: "Displaced", value: "50,000+" },
      { label: "Economic Loss", value: "$1.0B" },
      { label: "Recovery Time", value: "4 years" },
    ],
  },
  {
    id: "malaysia",
    name: "Malaysia",
    flag: "🇲🇾",
    region: "Southeast Asia",
    deathToll: 68,
    economicLoss: 500,
    affectedPopulation: 100000,
    recoveryYears: 2,
    description:
      "Malaysia's western coast experienced minor damage compared to other countries. The impact was primarily limited to Penang and Kedah states.",
    impact: {
      infrastructure: "Limited damage to coastal infrastructure",
      economy: "Minor disruption to fishing and tourism sectors",
      population: "Relatively low casualties due to distance from epicenter",
      recovery: "Quick recovery with minimal long-term economic impact",
    },
    keyStats: [
      { label: "Deaths", value: "68" },
      { label: "Displaced", value: "10,000+" },
      { label: "Economic Loss", value: "$0.5B" },
      { label: "Recovery Time", value: "2 years" },
    ],
  },
]

export default function Countries() {
  const [selectedCountry, setSelectedCountry] = useState(countries[0])

  return (
    <main className="min-h-screen bg-background">
      {/* Header */}
      <div className="bg-primary text-primary-foreground py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h1 className="text-4xl md:text-5xl font-bold mb-4">Country Impact Profiles</h1>
          <p className="text-lg opacity-90">Detailed analysis of how the tsunami affected individual nations</p>
        </div>
      </div>

      {/* Main Content */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        {/* Country Selection */}
        <div className="mb-12">
          <h2 className="text-2xl font-bold mb-6">Select a Country</h2>
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-3">
            {countries.map((country) => (
              <Button
                key={country.id}
                onClick={() => setSelectedCountry(country)}
                variant={selectedCountry.id === country.id ? "default" : "outline"}
                className="h-auto py-3 flex flex-col items-center gap-2"
              >
                <span className="text-2xl">{country.flag}</span>
                <span className="text-xs text-center">{country.name}</span>
              </Button>
            ))}
          </div>
        </div>

        {/* Selected Country Profile */}
        <div className="space-y-8">
          {/* Header Card */}
          <Card className="p-8 bg-gradient-to-r from-primary/10 to-accent/10 border-primary/20">
            <div className="flex items-start gap-4 mb-6">
              <span className="text-6xl">{selectedCountry.flag}</span>
              <div>
                <h1 className="text-4xl font-bold mb-2">{selectedCountry.name}</h1>
                <p className="text-muted-foreground flex items-center gap-2">
                  <MapPin className="w-4 h-4" />
                  {selectedCountry.region}
                </p>
              </div>
            </div>
            <p className="text-lg text-muted-foreground">{selectedCountry.description}</p>
          </Card>

          {/* Key Statistics */}
          <div className="grid md:grid-cols-4 gap-4">
            {selectedCountry.keyStats.map((stat, index) => (
              <Card key={index} className="p-6">
                <p className="text-muted-foreground text-sm mb-2">{stat.label}</p>
                <p className="text-3xl font-bold text-primary">{stat.value}</p>
              </Card>
            ))}
          </div>

          {/* Impact Analysis */}
          <div className="grid md:grid-cols-2 gap-6">
            <Card className="p-6 border-l-4 border-l-destructive">
              <div className="flex items-center gap-2 mb-4">
                <TrendingDown className="w-5 h-5 text-destructive" />
                <h3 className="text-xl font-bold">Economic Impact</h3>
              </div>
              <p className="text-muted-foreground">{selectedCountry.impact.economy}</p>
            </Card>

            <Card className="p-6 border-l-4 border-l-accent">
              <div className="flex items-center gap-2 mb-4">
                <Users className="w-5 h-5 text-accent" />
                <h3 className="text-xl font-bold">Population Impact</h3>
              </div>
              <p className="text-muted-foreground">{selectedCountry.impact.population}</p>
            </Card>

            <Card className="p-6 border-l-4 border-l-secondary">
              <div className="flex items-center gap-2 mb-4">
                <MapPin className="w-5 h-5 text-secondary" />
                <h3 className="text-xl font-bold">Infrastructure Damage</h3>
              </div>
              <p className="text-muted-foreground">{selectedCountry.impact.infrastructure}</p>
            </Card>

            <Card className="p-6 border-l-4 border-l-primary">
              <div className="flex items-center gap-2 mb-4">
                <Clock className="w-5 h-5 text-primary" />
                <h3 className="text-xl font-bold">Recovery Efforts</h3>
              </div>
              <p className="text-muted-foreground">{selectedCountry.impact.recovery}</p>
            </Card>
          </div>

          {/* Comparative Statistics */}
          <Card className="p-8">
            <h2 className="text-2xl font-bold mb-6">Comparative Statistics</h2>
            <div className="space-y-4">
              <div>
                <div className="flex justify-between mb-2">
                  <span className="font-semibold">Death Toll</span>
                  <span className="text-muted-foreground">{selectedCountry.deathToll.toLocaleString()}</span>
                </div>
                <div className="w-full bg-muted rounded-full h-2">
                  <div
                    className="bg-destructive h-2 rounded-full"
                    style={{ width: `${(selectedCountry.deathToll / 167000) * 100}%` }}
                  ></div>
                </div>
              </div>

              <div>
                <div className="flex justify-between mb-2">
                  <span className="font-semibold">Economic Loss ($ Billions)</span>
                  <span className="text-muted-foreground">${selectedCountry.economicLoss}B</span>
                </div>
                <div className="w-full bg-muted rounded-full h-2">
                  <div
                    className="bg-primary h-2 rounded-full"
                    style={{ width: `${(selectedCountry.economicLoss / 4500) * 100}%` }}
                  ></div>
                </div>
              </div>

              <div>
                <div className="flex justify-between mb-2">
                  <span className="font-semibold">Affected Population (Millions)</span>
                  <span className="text-muted-foreground">
                    {(selectedCountry.affectedPopulation / 1000000).toFixed(1)}M
                  </span>
                </div>
                <div className="w-full bg-muted rounded-full h-2">
                  <div
                    className="bg-accent h-2 rounded-full"
                    style={{ width: `${(selectedCountry.affectedPopulation / 1200000) * 100}%` }}
                  ></div>
                </div>
              </div>

              <div>
                <div className="flex justify-between mb-2">
                  <span className="font-semibold">Recovery Period (Years)</span>
                  <span className="text-muted-foreground">{selectedCountry.recoveryYears} years</span>
                </div>
                <div className="w-full bg-muted rounded-full h-2">
                  <div
                    className="bg-secondary h-2 rounded-full"
                    style={{ width: `${(selectedCountry.recoveryYears / 7) * 100}%` }}
                  ></div>
                </div>
              </div>
            </div>
          </Card>

          {/* All Countries Overview */}
          <Card className="p-8 bg-muted/50">
            <h2 className="text-2xl font-bold mb-6">All Affected Countries Overview</h2>
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="border-b border-border">
                    <th className="text-left py-3 px-4 font-semibold">Country</th>
                    <th className="text-right py-3 px-4 font-semibold">Deaths</th>
                    <th className="text-right py-3 px-4 font-semibold">Economic Loss</th>
                    <th className="text-right py-3 px-4 font-semibold">Affected Pop.</th>
                    <th className="text-right py-3 px-4 font-semibold">Recovery</th>
                  </tr>
                </thead>
                <tbody>
                  {countries.map((country) => (
                    <tr key={country.id} className="border-b border-border hover:bg-background/50 transition">
                      <td className="py-3 px-4 font-medium">{country.name}</td>
                      <td className="text-right py-3 px-4 text-muted-foreground">
                        {country.deathToll.toLocaleString()}
                      </td>
                      <td className="text-right py-3 px-4 text-muted-foreground">${country.economicLoss}B</td>
                      <td className="text-right py-3 px-4 text-muted-foreground">
                        {(country.affectedPopulation / 1000000).toFixed(1)}M
                      </td>
                      <td className="text-right py-3 px-4 text-muted-foreground">{country.recoveryYears} yrs</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </Card>
        </div>
      </div>
    </main>
  )
}
