import { Card } from "@/components/ui/card"
import { AlertCircle, CheckCircle, Clock } from "lucide-react"

const timelineEvents = [
  {
    date: "December 26, 2004",
    time: "07:59 AM",
    title: "The Earthquake Strikes",
    description:
      "A massive 9.1-9.3 magnitude earthquake occurs off the coast of Sumatra, Indonesia. It is the second-largest earthquake ever recorded.",
    impact: "Immediate",
    icon: AlertCircle,
  },
  {
    date: "December 26, 2004",
    time: "08:15 AM",
    title: "Tsunami Waves Generated",
    description:
      "The earthquake displaces massive amounts of water, generating tsunami waves that travel across the Indian Ocean at speeds up to 500 mph.",
    impact: "Immediate",
    icon: AlertCircle,
  },
  {
    date: "December 26, 2004",
    time: "09:00 AM - 10:00 AM",
    title: "First Waves Hit",
    description:
      "Waves reach Indonesia, Thailand, and other nearby countries. The waves range from 30-100 feet high in some areas, devastating coastal communities.",
    impact: "Catastrophic",
    icon: AlertCircle,
  },
  {
    date: "December 26, 2004",
    time: "10:00 AM - 2:00 PM",
    title: "Waves Reach Africa",
    description:
      "The tsunami reaches East Africa, including Somalia, Kenya, and Tanzania. Despite traveling thousands of miles, waves still cause significant damage.",
    impact: "Severe",
    icon: AlertCircle,
  },
  {
    date: "December 26-27, 2004",
    time: "Throughout the day",
    title: "Initial Death Toll Emerges",
    description:
      "Reports begin coming in of massive casualties. Initial estimates suggest tens of thousands dead, with numbers rising as communication is restored.",
    impact: "Crisis",
    icon: AlertCircle,
  },
  {
    date: "December 27-31, 2004",
    time: "Days 2-5",
    title: "International Response Mobilizes",
    description:
      "The United Nations, Red Cross, and international governments launch emergency relief operations. Rescue teams and medical personnel are deployed to affected regions.",
    impact: "Response",
    icon: Clock,
  },
  {
    date: "January 2005",
    time: "Week 2",
    title: "Humanitarian Crisis Deepens",
    description:
      "Disease outbreaks threaten survivors. Cholera, dysentery, and other waterborne illnesses spread rapidly due to contaminated water supplies and poor sanitation.",
    impact: "Secondary Crisis",
    icon: AlertCircle,
  },
  {
    date: "January-March 2005",
    time: "Months 2-3",
    title: "Reconstruction Begins",
    description:
      "Governments and NGOs begin planning reconstruction efforts. Temporary shelters are established, and debris removal operations commence in major cities.",
    impact: "Recovery",
    icon: CheckCircle,
  },
  {
    date: "2005-2006",
    time: "Year 2",
    title: "Major Infrastructure Projects",
    description:
      "Large-scale reconstruction of roads, ports, and housing begins. International funding reaches $14 billion for recovery efforts across affected nations.",
    impact: "Rebuilding",
    icon: CheckCircle,
  },
  {
    date: "2006-2008",
    time: "Years 3-4",
    title: "Economic Recovery Accelerates",
    description:
      "Tourism sectors begin to recover. Fishing industries are rebuilt with new equipment and training. Agricultural lands are restored and replanted.",
    impact: "Progress",
    icon: CheckCircle,
  },
  {
    date: "2008-2010",
    time: "Years 4-6",
    title: "Long-term Development",
    description:
      "Focus shifts to building resilience and disaster preparedness. Early warning systems are installed across the Indian Ocean region.",
    impact: "Prevention",
    icon: CheckCircle,
  },
  {
    date: "2010 onwards",
    time: "Year 6+",
    title: "Ongoing Recovery & Resilience",
    description:
      "Communities continue rebuilding and adapting. Lessons learned lead to improved disaster preparedness globally and stronger building codes in coastal areas.",
    impact: "Resilience",
    icon: CheckCircle,
  },
]

const recoveryStats = [
  {
    title: "Immediate Response",
    items: ["230,000+ lives lost", "5+ million people affected", "14 countries impacted", "$15 billion in damages"],
  },
  {
    title: "First Year Recovery",
    items: [
      "$14 billion pledged internationally",
      "1 million+ temporary shelters built",
      "Disease outbreaks contained",
      "Supply chains partially restored",
    ],
  },
  {
    title: "Long-term Reconstruction",
    items: [
      "5-10 years average recovery period",
      "New building codes implemented",
      "Early warning systems installed",
      "Economic sectors gradually restored",
    ],
  },
]

export default function Timeline() {
  return (
    <main className="min-h-screen bg-background">
      {/* Header */}
      <div className="bg-primary text-primary-foreground py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h1 className="text-4xl md:text-5xl font-bold mb-4">Timeline & Recovery</h1>
          <p className="text-lg opacity-90">A chronological account of the disaster and the long journey to recovery</p>
        </div>
      </div>

      {/* Main Content */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        {/* Recovery Stats */}
        <div className="grid md:grid-cols-3 gap-6 mb-16">
          {recoveryStats.map((stat, index) => (
            <Card key={index} className="p-6">
              <h3 className="text-xl font-bold mb-4 text-primary">{stat.title}</h3>
              <ul className="space-y-2">
                {stat.items.map((item, itemIndex) => (
                  <li key={itemIndex} className="flex items-start gap-2 text-muted-foreground">
                    <div className="w-2 h-2 bg-accent rounded-full mt-2 flex-shrink-0"></div>
                    <span>{item}</span>
                  </li>
                ))}
              </ul>
            </Card>
          ))}
        </div>

        {/* Timeline */}
        <div className="mb-12">
          <h2 className="text-3xl font-bold mb-12 text-center">Detailed Timeline of Events</h2>

          <div className="relative">
            {/* Timeline line */}
            <div className="absolute left-0 md:left-1/2 top-0 bottom-0 w-1 bg-gradient-to-b from-primary via-accent to-secondary transform md:-translate-x-1/2"></div>

            {/* Timeline events */}
            <div className="space-y-12">
              {timelineEvents.map((event, index) => {
                const Icon = event.icon
                const isLeft = index % 2 === 0
                const isDisaster = index < 5
                const borderColor = isDisaster ? "border-l-destructive" : "border-l-accent"
                const bgColor = isDisaster ? "bg-destructive/5" : "bg-accent/5"

                return (
                  <div key={index} className={`flex ${isLeft ? "md:flex-row-reverse" : ""}`}>
                    {/* Content */}
                    <div className={`w-full md:w-1/2 ${isLeft ? "md:pr-12" : "md:pl-12"}`}>
                      <Card className={`p-6 border-l-4 ${borderColor} ${bgColor}`}>
                        {/* Timeline dot */}
                        <div className="absolute left-0 md:left-1/2 top-8 w-6 h-6 bg-background border-4 border-primary rounded-full transform -translate-x-1/2 md:-translate-x-1/2 md:translate-x-1/2"></div>

                        <div className="flex items-start gap-3 mb-3">
                          <Icon className="w-5 h-5 text-primary flex-shrink-0 mt-1" />
                          <div>
                            <p className="text-sm font-semibold text-primary">{event.date}</p>
                            <p className="text-xs text-muted-foreground">{event.time}</p>
                          </div>
                        </div>

                        <h3 className="text-xl font-bold mb-2">{event.title}</h3>
                        <p className="text-muted-foreground mb-4">{event.description}</p>

                        <div className="flex items-center gap-2">
                          <span className="text-xs font-semibold px-3 py-1 rounded-full bg-primary/10 text-primary">
                            {event.impact}
                          </span>
                        </div>
                      </Card>
                    </div>
                  </div>
                )
              })}
            </div>
          </div>
        </div>

        {/* Recovery Phases */}
        <div className="mt-16">
          <h2 className="text-3xl font-bold mb-8 text-center">Recovery Phases</h2>
          <div className="grid md:grid-cols-4 gap-4">
            <Card className="p-6 border-t-4 border-t-destructive">
              <h3 className="font-bold text-lg mb-2">Phase 1: Emergency</h3>
              <p className="text-sm text-muted-foreground mb-3">Days 1-7</p>
              <ul className="text-sm space-y-1 text-muted-foreground">
                <li>• Search & rescue</li>
                <li>• Emergency aid</li>
                <li>• Medical care</li>
              </ul>
            </Card>

            <Card className="p-6 border-t-4 border-t-accent">
              <h3 className="font-bold text-lg mb-2">Phase 2: Relief</h3>
              <p className="text-sm text-muted-foreground mb-3">Weeks 2-12</p>
              <ul className="text-sm space-y-1 text-muted-foreground">
                <li>• Temporary shelter</li>
                <li>• Disease prevention</li>
                <li>• Supply distribution</li>
              </ul>
            </Card>

            <Card className="p-6 border-t-4 border-t-secondary">
              <h3 className="font-bold text-lg mb-2">Phase 3: Reconstruction</h3>
              <p className="text-sm text-muted-foreground mb-3">Months 3-24</p>
              <ul className="text-sm space-y-1 text-muted-foreground">
                <li>• Infrastructure rebuild</li>
                <li>• Housing restoration</li>
                <li>• Economic restart</li>
              </ul>
            </Card>

            <Card className="p-6 border-t-4 border-t-primary">
              <h3 className="font-bold text-lg mb-2">Phase 4: Development</h3>
              <p className="text-sm text-muted-foreground mb-3">Years 2-10+</p>
              <ul className="text-sm space-y-1 text-muted-foreground">
                <li>• Long-term growth</li>
                <li>• Resilience building</li>
                <li>• Prevention systems</li>
              </ul>
            </Card>
          </div>
        </div>

        {/* Key Lessons */}
        <Card className="p-8 mt-12 bg-primary/5 border-primary/20">
          <h2 className="text-2xl font-bold mb-6">Key Lessons Learned</h2>
          <div className="grid md:grid-cols-2 gap-6">
            <div>
              <h3 className="font-bold mb-3 text-primary">Disaster Preparedness</h3>
              <ul className="space-y-2 text-muted-foreground text-sm">
                <li>• Early warning systems are critical</li>
                <li>• Evacuation plans must be practiced</li>
                <li>• Communication infrastructure is essential</li>
              </ul>
            </div>
            <div>
              <h3 className="font-bold mb-3 text-primary">Infrastructure Resilience</h3>
              <ul className="space-y-2 text-muted-foreground text-sm">
                <li>• Building codes must account for natural disasters</li>
                <li>• Coastal protection measures are vital</li>
                <li>• Redundant systems prevent total collapse</li>
              </ul>
            </div>
            <div>
              <h3 className="font-bold mb-3 text-primary">International Cooperation</h3>
              <ul className="space-y-2 text-muted-foreground text-sm">
                <li>• Global coordination accelerates recovery</li>
                <li>• Shared resources maximize impact</li>
                <li>• Knowledge transfer prevents future losses</li>
              </ul>
            </div>
            <div>
              <h3 className="font-bold mb-3 text-primary">Community Resilience</h3>
              <ul className="space-y-2 text-muted-foreground text-sm">
                <li>• Local knowledge is invaluable</li>
                <li>• Community involvement speeds recovery</li>
                <li>• Mental health support is crucial</li>
              </ul>
            </div>
          </div>
        </Card>
      </div>
    </main>
  )
}
