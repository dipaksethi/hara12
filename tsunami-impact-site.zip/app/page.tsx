import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { ArrowRight, TrendingDown, Users, Globe } from "lucide-react"

export default function Home() {
  return (
    <main className="min-h-screen bg-gradient-to-b from-background to-muted">
      {/* Navigation */}
      <nav className="sticky top-0 z-50 bg-background/80 backdrop-blur-md border-b border-border">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4 flex items-center justify-between">
          <div className="text-2xl font-bold text-primary">2004 Tsunami</div>
          <div className="hidden md:flex gap-8">
            <Link href="#impact" className="text-foreground hover:text-primary transition">
              Impact
            </Link>
            <Link href="/dashboard" className="text-foreground hover:text-primary transition">
              Dashboard
            </Link>
            <Link href="/timeline" className="text-foreground hover:text-primary transition">
              Timeline
            </Link>
            <Link href="/countries" className="text-foreground hover:text-primary transition">
              Countries
            </Link>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="relative overflow-hidden py-20 md:py-32">
        <div className="absolute inset-0 opacity-10">
          <div className="absolute top-20 left-10 w-72 h-72 bg-primary rounded-full mix-blend-multiply filter blur-3xl animate-wave"></div>
          <div
            className="absolute top-40 right-10 w-72 h-72 bg-accent rounded-full mix-blend-multiply filter blur-3xl animate-wave"
            style={{ animationDelay: "2s" }}
          ></div>
        </div>

        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h1 className="text-5xl md:text-7xl font-bold text-balance mb-6">The 2004 Indian Ocean Tsunami</h1>
          <p className="text-xl md:text-2xl text-muted-foreground text-balance mb-8 max-w-3xl mx-auto">
            Understanding the Economic Impact of One of History's Deadliest Natural Disasters
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link href="/dashboard">
              <Button size="lg" className="gap-2">
                Explore Impact <ArrowRight className="w-4 h-4" />
              </Button>
            </Link>
            <Link href="/timeline">
              <Button size="lg" variant="outline">
                View Timeline
              </Button>
            </Link>
          </div>
        </div>
      </section>

      {/* Key Statistics */}
      <section id="impact" className="py-20 bg-card/50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="text-4xl font-bold mb-12 text-center">The Scale of Impact</h2>
          <div className="grid md:grid-cols-3 gap-6">
            <Card className="p-8 border-l-4 border-l-primary">
              <div className="flex items-start gap-4">
                <Users className="w-8 h-8 text-primary flex-shrink-0 mt-1" />
                <div>
                  <p className="text-muted-foreground text-sm mb-2">Lives Lost</p>
                  <p className="text-4xl font-bold">230,000+</p>
                  <p className="text-sm text-muted-foreground mt-2">Across 14 countries</p>
                </div>
              </div>
            </Card>

            <Card className="p-8 border-l-4 border-l-accent">
              <div className="flex items-start gap-4">
                <TrendingDown className="w-8 h-8 text-accent flex-shrink-0 mt-1" />
                <div>
                  <p className="text-muted-foreground text-sm mb-2">Economic Loss</p>
                  <p className="text-4xl font-bold">$15 Billion</p>
                  <p className="text-sm text-muted-foreground mt-2">USD in damages</p>
                </div>
              </div>
            </Card>

            <Card className="p-8 border-l-4 border-l-secondary">
              <div className="flex items-start gap-4">
                <Globe className="w-8 h-8 text-secondary flex-shrink-0 mt-1" />
                <div>
                  <p className="text-muted-foreground text-sm mb-2">Affected Countries</p>
                  <p className="text-4xl font-bold">14</p>
                  <p className="text-sm text-muted-foreground mt-2">From Africa to Asia</p>
                </div>
              </div>
            </Card>
          </div>
        </div>
      </section>

      {/* Featured Sections */}
      <section className="py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="text-4xl font-bold mb-12 text-center">Explore the Crisis</h2>
          <div className="grid md:grid-cols-2 gap-8">
            <Link href="/dashboard" className="group">
              <Card className="p-8 h-full hover:shadow-lg transition cursor-pointer">
                <h3 className="text-2xl font-bold mb-4 group-hover:text-primary transition">Economic Dashboard</h3>
                <p className="text-muted-foreground mb-6">
                  Interactive visualizations showing the economic impact across sectors and countries, including
                  infrastructure damage, GDP effects, and recovery costs.
                </p>
                <div className="flex items-center text-primary font-semibold">
                  View Dashboard <ArrowRight className="w-4 h-4 ml-2 group-hover:translate-x-1 transition" />
                </div>
              </Card>
            </Link>

            <Link href="/timeline" className="group">
              <Card className="p-8 h-full hover:shadow-lg transition cursor-pointer">
                <h3 className="text-2xl font-bold mb-4 group-hover:text-primary transition">Timeline & Recovery</h3>
                <p className="text-muted-foreground mb-6">
                  A detailed chronological account of the disaster, immediate response, and the long-term recovery
                  efforts that shaped affected nations.
                </p>
                <div className="flex items-center text-primary font-semibold">
                  View Timeline <ArrowRight className="w-4 h-4 ml-2 group-hover:translate-x-1 transition" />
                </div>
              </Card>
            </Link>

            <Link href="/countries" className="group">
              <Card className="p-8 h-full hover:shadow-lg transition cursor-pointer">
                <h3 className="text-2xl font-bold mb-4 group-hover:text-primary transition">Country Profiles</h3>
                <p className="text-muted-foreground mb-6">
                  In-depth analysis of how the tsunami affected individual nations, including Indonesia, Thailand,
                  India, and Sri Lanka.
                </p>
                <div className="flex items-center text-primary font-semibold">
                  Explore Countries <ArrowRight className="w-4 h-4 ml-2 group-hover:translate-x-1 transition" />
                </div>
              </Card>
            </Link>

            <Card className="p-8 h-full bg-primary/5 border-primary/20">
              <h3 className="text-2xl font-bold mb-4">Key Sectors Affected</h3>
              <ul className="space-y-3 text-muted-foreground">
                <li className="flex items-center gap-2">
                  <div className="w-2 h-2 bg-primary rounded-full"></div>
                  Fishing & Aquaculture
                </li>
                <li className="flex items-center gap-2">
                  <div className="w-2 h-2 bg-primary rounded-full"></div>
                  Tourism & Hospitality
                </li>
                <li className="flex items-center gap-2">
                  <div className="w-2 h-2 bg-primary rounded-full"></div>
                  Infrastructure & Housing
                </li>
                <li className="flex items-center gap-2">
                  <div className="w-2 h-2 bg-primary rounded-full"></div>
                  Agriculture & Livelihoods
                </li>
              </ul>
            </Card>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-primary text-primary-foreground py-12 border-t border-border">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid md:grid-cols-4 gap-8 mb-8">
            <div>
              <h4 className="font-bold mb-4">Navigation</h4>
              <ul className="space-y-2 text-sm opacity-90">
                <li>
                  <Link href="/" className="hover:opacity-100">
                    Home
                  </Link>
                </li>
                <li>
                  <Link href="/dashboard" className="hover:opacity-100">
                    Dashboard
                  </Link>
                </li>
                <li>
                  <Link href="/timeline" className="hover:opacity-100">
                    Timeline
                  </Link>
                </li>
                <li>
                  <Link href="/countries" className="hover:opacity-100">
                    Countries
                  </Link>
                </li>
              </ul>
            </div>
            <div>
              <h4 className="font-bold mb-4">Resources</h4>
              <ul className="space-y-2 text-sm opacity-90">
                <li>
                  <a href="#" className="hover:opacity-100">
                    Research Papers
                  </a>
                </li>
                <li>
                  <a href="#" className="hover:opacity-100">
                    Statistics
                  </a>
                </li>
                <li>
                  <a href="#" className="hover:opacity-100">
                    Reports
                  </a>
                </li>
              </ul>
            </div>
            <div>
              <h4 className="font-bold mb-4">About</h4>
              <ul className="space-y-2 text-sm opacity-90">
                <li>
                  <a href="#" className="hover:opacity-100">
                    Our Mission
                  </a>
                </li>
                <li>
                  <a href="#" className="hover:opacity-100">
                    Contact
                  </a>
                </li>
                <li>
                  <a href="#" className="hover:opacity-100">
                    Contribute
                  </a>
                </li>
              </ul>
            </div>
            <div>
              <h4 className="font-bold mb-4">Learn More</h4>
              <p className="text-sm opacity-90">
                Understanding natural disasters helps us build resilience and prepare for the future.
              </p>
            </div>
          </div>
          <div className="border-t border-primary-foreground/20 pt-8 text-center text-sm opacity-75">
            <p>2004 Indian Ocean Tsunami - Educational Resource | Honoring those affected</p>
          </div>
        </div>
      </footer>
    </main>
  )
}
