"use client"

import { useState } from "react"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import {
  BarChart,
  Bar,
  LineChart,
  Line,
  Area,
  ScatterChart,
  Scatter,
  RadarChart,
  PolarGrid,
  PolarAngleAxis,
  PolarRadiusAxis,
  Radar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
  ComposedChart,
} from "recharts"

const countryComparisonData = [
  { country: "Indonesia", deaths: 167, economic: 4500, recovery: 7, population: 1200 },
  { country: "Thailand", deaths: 5.4, economic: 3000, recovery: 5, population: 800 },
  { country: "Sri Lanka", deaths: 35, economic: 2800, recovery: 6, population: 900 },
  { country: "India", deaths: 16, economic: 2200, recovery: 5, population: 600 },
  { country: "Somalia", deaths: 0.3, economic: 1000, recovery: 4, population: 200 },
  { country: "Malaysia", deaths: 0.068, economic: 500, recovery: 2, population: 100 },
]

const timelineData = [
  { month: "Dec 2004", deaths: 230, homeless: 1500, aid: 100 },
  { month: "Jan 2005", deaths: 230, homeless: 1800, aid: 2500 },
  { month: "Feb 2005", deaths: 230, homeless: 1600, aid: 4200 },
  { month: "Mar 2005", deaths: 230, homeless: 1200, aid: 5800 },
  { month: "Apr 2005", deaths: 230, homeless: 900, aid: 7200 },
  { month: "May 2005", deaths: 230, homeless: 700, aid: 8500 },
  { month: "Jun 2005", deaths: 230, homeless: 500, aid: 9200 },
]

const sectorRecoveryData = [
  { year: 2004, fishing: 10, tourism: 5, agriculture: 15, infrastructure: 8 },
  { year: 2005, fishing: 25, tourism: 15, agriculture: 35, infrastructure: 30 },
  { year: 2006, fishing: 40, tourism: 35, agriculture: 55, infrastructure: 50 },
  { year: 2007, fishing: 55, tourism: 55, agriculture: 70, infrastructure: 65 },
  { year: 2008, fishing: 70, tourism: 75, agriculture: 80, infrastructure: 80 },
  { year: 2009, fishing: 85, tourism: 90, agriculture: 90, infrastructure: 90 },
  { year: 2010, fishing: 95, tourism: 95, agriculture: 95, infrastructure: 95 },
]

const radarData = [
  { category: "Deaths", Indonesia: 167, Thailand: 5.4, "Sri Lanka": 35, India: 16 },
  { category: "Economic Loss", Indonesia: 90, Thailand: 67, "Sri Lanka": 62, India: 49 },
  { category: "Population Affected", Indonesia: 100, Thailand: 67, "Sri Lanka": 75, India: 50 },
  { category: "Recovery Time", Indonesia: 100, Thailand: 71, "Sri Lanka": 86, India: 71 },
  { category: "Infrastructure Damage", Indonesia: 95, Thailand: 80, "Sri Lanka": 85, India: 70 },
]

const waveSpreadData = [
  { distance: 0, time: 0, waveHeight: 100 },
  { distance: 100, time: 12, waveHeight: 95 },
  { distance: 300, time: 36, waveHeight: 85 },
  { distance: 500, time: 60, waveHeight: 75 },
  { distance: 1000, time: 120, waveHeight: 60 },
  { distance: 1500, time: 180, waveHeight: 45 },
  { distance: 2000, time: 240, waveHeight: 35 },
  { distance: 3000, time: 360, waveHeight: 20 },
]

export default function Visualizations() {
  const [activeChart, setActiveChart] = useState("comparison")

  return (
    <main className="min-h-screen bg-background">
      {/* Header */}
      <div className="bg-primary text-primary-foreground py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h1 className="text-4xl md:text-5xl font-bold mb-4">Interactive Data Visualizations</h1>
          <p className="text-lg opacity-90">Explore the 2004 tsunami impact through interactive charts and graphs</p>
        </div>
      </div>

      {/* Main Content */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        {/* Chart Navigation */}
        <div className="mb-12">
          <h2 className="text-2xl font-bold mb-6">Select Visualization</h2>
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-3">
            <Button
              onClick={() => setActiveChart("comparison")}
              variant={activeChart === "comparison" ? "default" : "outline"}
              className="h-auto py-3"
            >
              <span className="text-center text-sm">Country Comparison</span>
            </Button>
            <Button
              onClick={() => setActiveChart("timeline")}
              variant={activeChart === "timeline" ? "default" : "outline"}
              className="h-auto py-3"
            >
              <span className="text-center text-sm">Response Timeline</span>
            </Button>
            <Button
              onClick={() => setActiveChart("recovery")}
              variant={activeChart === "recovery" ? "default" : "outline"}
              className="h-auto py-3"
            >
              <span className="text-center text-sm">Sector Recovery</span>
            </Button>
            <Button
              onClick={() => setActiveChart("radar")}
              variant={activeChart === "radar" ? "default" : "outline"}
              className="h-auto py-3"
            >
              <span className="text-center text-sm">Impact Radar</span>
            </Button>
            <Button
              onClick={() => setActiveChart("wave")}
              variant={activeChart === "wave" ? "default" : "outline"}
              className="h-auto py-3"
            >
              <span className="text-center text-sm">Wave Spread</span>
            </Button>
            <Button
              onClick={() => setActiveChart("composed")}
              variant={activeChart === "composed" ? "default" : "outline"}
              className="h-auto py-3"
            >
              <span className="text-center text-sm">Combined Data</span>
            </Button>
          </div>
        </div>

        {/* Active Chart */}
        <Card className="p-8 mb-12">
          {activeChart === "comparison" && (
            <div>
              <h2 className="text-2xl font-bold mb-6">Country Impact Comparison</h2>
              <p className="text-muted-foreground mb-6">
                Compare deaths, economic loss, affected population, and recovery time across affected countries
              </p>
              <ResponsiveContainer width="100%" height={400}>
                <BarChart data={countryComparisonData}>
                  <CartesianGrid strokeDasharray="3 3" stroke="var(--color-border)" />
                  <XAxis dataKey="country" stroke="var(--color-muted-foreground)" />
                  <YAxis stroke="var(--color-muted-foreground)" />
                  <Tooltip
                    contentStyle={{
                      backgroundColor: "var(--color-card)",
                      border: "1px solid var(--color-border)",
                      borderRadius: "var(--radius)",
                    }}
                  />
                  <Legend />
                  <Bar dataKey="deaths" fill="var(--color-destructive)" name="Deaths (thousands)" />
                  <Bar dataKey="economic" fill="var(--color-primary)" name="Economic Loss ($M)" />
                </BarChart>
              </ResponsiveContainer>
            </div>
          )}

          {activeChart === "timeline" && (
            <div>
              <h2 className="text-2xl font-bold mb-6">Emergency Response Timeline</h2>
              <p className="text-muted-foreground mb-6">
                Tracking humanitarian aid deployment and homelessness reduction over the first 6 months
              </p>
              <ResponsiveContainer width="100%" height={400}>
                <ComposedChart data={timelineData}>
                  <CartesianGrid strokeDasharray="3 3" stroke="var(--color-border)" />
                  <XAxis dataKey="month" stroke="var(--color-muted-foreground)" />
                  <YAxis stroke="var(--color-muted-foreground)" />
                  <Tooltip
                    contentStyle={{
                      backgroundColor: "var(--color-card)",
                      border: "1px solid var(--color-border)",
                      borderRadius: "var(--radius)",
                    }}
                  />
                  <Legend />
                  <Area
                    type="monotone"
                    dataKey="homeless"
                    fill="var(--color-accent)"
                    stroke="var(--color-accent)"
                    name="Homeless (thousands)"
                    opacity={0.6}
                  />
                  <Line
                    type="monotone"
                    dataKey="aid"
                    stroke="var(--color-primary)"
                    strokeWidth={2}
                    name="Aid Deployed ($M)"
                  />
                </ComposedChart>
              </ResponsiveContainer>
            </div>
          )}

          {activeChart === "recovery" && (
            <div>
              <h2 className="text-2xl font-bold mb-6">Sector Recovery Progress</h2>
              <p className="text-muted-foreground mb-6">
                Recovery percentage by sector from 2004 to 2010 (0% = complete loss, 100% = full recovery)
              </p>
              <ResponsiveContainer width="100%" height={400}>
                <LineChart data={sectorRecoveryData}>
                  <CartesianGrid strokeDasharray="3 3" stroke="var(--color-border)" />
                  <XAxis dataKey="year" stroke="var(--color-muted-foreground)" />
                  <YAxis stroke="var(--color-muted-foreground)" domain={[0, 100]} />
                  <Tooltip
                    contentStyle={{
                      backgroundColor: "var(--color-card)",
                      border: "1px solid var(--color-border)",
                      borderRadius: "var(--radius)",
                    }}
                    formatter={(value) => `${value}%`}
                  />
                  <Legend />
                  <Line
                    type="monotone"
                    dataKey="fishing"
                    stroke="var(--color-chart-1)"
                    strokeWidth={2}
                    name="Fishing"
                  />
                  <Line
                    type="monotone"
                    dataKey="tourism"
                    stroke="var(--color-chart-2)"
                    strokeWidth={2}
                    name="Tourism"
                  />
                  <Line
                    type="monotone"
                    dataKey="agriculture"
                    stroke="var(--color-chart-3)"
                    strokeWidth={2}
                    name="Agriculture"
                  />
                  <Line
                    type="monotone"
                    dataKey="infrastructure"
                    stroke="var(--color-chart-4)"
                    strokeWidth={2}
                    name="Infrastructure"
                  />
                </LineChart>
              </ResponsiveContainer>
            </div>
          )}

          {activeChart === "radar" && (
            <div>
              <h2 className="text-2xl font-bold mb-6">Multi-Dimensional Impact Radar</h2>
              <p className="text-muted-foreground mb-6">
                Compare multiple impact dimensions across the four most affected countries
              </p>
              <ResponsiveContainer width="100%" height={400}>
                <RadarChart data={radarData}>
                  <PolarGrid stroke="var(--color-border)" />
                  <PolarAngleAxis dataKey="category" stroke="var(--color-muted-foreground)" />
                  <PolarRadiusAxis stroke="var(--color-muted-foreground)" />
                  <Radar
                    name="Indonesia"
                    dataKey="Indonesia"
                    stroke="var(--color-primary)"
                    fill="var(--color-primary)"
                    fillOpacity={0.25}
                  />
                  <Radar
                    name="Thailand"
                    dataKey="Thailand"
                    stroke="var(--color-accent)"
                    fill="var(--color-accent)"
                    fillOpacity={0.25}
                  />
                  <Radar
                    name="Sri Lanka"
                    dataKey="Sri Lanka"
                    stroke="var(--color-secondary)"
                    fill="var(--color-secondary)"
                    fillOpacity={0.25}
                  />
                  <Radar
                    name="India"
                    dataKey="India"
                    stroke="var(--color-chart-4)"
                    fill="var(--color-chart-4)"
                    fillOpacity={0.25}
                  />
                  <Legend />
                </RadarChart>
              </ResponsiveContainer>
            </div>
          )}

          {activeChart === "wave" && (
            <div>
              <h2 className="text-2xl font-bold mb-6">Tsunami Wave Propagation</h2>
              <p className="text-muted-foreground mb-6">
                Wave height decrease as the tsunami traveled across the Indian Ocean (distance in km, time in minutes)
              </p>
              <ResponsiveContainer width="100%" height={400}>
                <ScatterChart data={waveSpreadData} margin={{ top: 20, right: 20, bottom: 20, left: 20 }}>
                  <CartesianGrid strokeDasharray="3 3" stroke="var(--color-border)" />
                  <XAxis
                    dataKey="distance"
                    name="Distance (km)"
                    stroke="var(--color-muted-foreground)"
                    label={{ value: "Distance (km)", position: "insideBottomRight", offset: -5 }}
                  />
                  <YAxis
                    dataKey="waveHeight"
                    name="Wave Height (feet)"
                    stroke="var(--color-muted-foreground)"
                    label={{ value: "Wave Height (feet)", angle: -90, position: "insideLeft" }}
                  />
                  <Tooltip
                    contentStyle={{
                      backgroundColor: "var(--color-card)",
                      border: "1px solid var(--color-border)",
                      borderRadius: "var(--radius)",
                    }}
                    cursor={{ strokeDasharray: "3 3" }}
                  />
                  <Scatter name="Wave Height" dataKey="waveHeight" fill="var(--color-primary)" />
                </ScatterChart>
              </ResponsiveContainer>
            </div>
          )}

          {activeChart === "composed" && (
            <div>
              <h2 className="text-2xl font-bold mb-6">Combined Impact Analysis</h2>
              <p className="text-muted-foreground mb-6">
                Multi-metric view showing deaths, economic loss, and recovery time by country
              </p>
              <ResponsiveContainer width="100%" height={400}>
                <ComposedChart data={countryComparisonData}>
                  <CartesianGrid strokeDasharray="3 3" stroke="var(--color-border)" />
                  <XAxis dataKey="country" stroke="var(--color-muted-foreground)" />
                  <YAxis yAxisId="left" stroke="var(--color-muted-foreground)" />
                  <YAxis yAxisId="right" orientation="right" stroke="var(--color-muted-foreground)" />
                  <Tooltip
                    contentStyle={{
                      backgroundColor: "var(--color-card)",
                      border: "1px solid var(--color-border)",
                      borderRadius: "var(--radius)",
                    }}
                  />
                  <Legend />
                  <Bar yAxisId="left" dataKey="deaths" fill="var(--color-destructive)" name="Deaths (thousands)" />
                  <Line
                    yAxisId="right"
                    type="monotone"
                    dataKey="recovery"
                    stroke="var(--color-primary)"
                    strokeWidth={2}
                    name="Recovery (years)"
                  />
                </ComposedChart>
              </ResponsiveContainer>
            </div>
          )}
        </Card>

        {/* Insights Section */}
        <div className="grid md:grid-cols-2 gap-6">
          <Card className="p-6 bg-primary/5 border-primary/20">
            <h3 className="text-xl font-bold mb-4 text-primary">Key Insights</h3>
            <ul className="space-y-3 text-muted-foreground text-sm">
              <li className="flex gap-2">
                <span className="text-primary font-bold">•</span>
                <span>Indonesia accounted for 73% of total deaths despite being one of many affected countries</span>
              </li>
              <li className="flex gap-2">
                <span className="text-primary font-bold">•</span>
                <span>Economic recovery varied significantly, with tourism-dependent nations recovering faster</span>
              </li>
              <li className="flex gap-2">
                <span className="text-primary font-bold">•</span>
                <span>Wave heights decreased exponentially with distance, yet still caused damage 3000+ km away</span>
              </li>
              <li className="flex gap-2">
                <span className="text-primary font-bold">•</span>
                <span>Fishing sector took longest to recover due to fleet destruction and ecosystem damage</span>
              </li>
            </ul>
          </Card>

          <Card className="p-6 bg-accent/5 border-accent/20">
            <h3 className="text-xl font-bold mb-4 text-accent">Data Interpretation</h3>
            <ul className="space-y-3 text-muted-foreground text-sm">
              <li className="flex gap-2">
                <span className="text-accent font-bold">•</span>
                <span>Recovery timelines show infrastructure recovered faster than livelihoods</span>
              </li>
              <li className="flex gap-2">
                <span className="text-accent font-bold">•</span>
                <span>
                  International aid peaked in early 2005, then gradually decreased as local capacity increased
                </span>
              </li>
              <li className="flex gap-2">
                <span className="text-accent font-bold">•</span>
                <span>Multi-dimensional radar shows Indonesia's impact was severe across all metrics</span>
              </li>
              <li className="flex gap-2">
                <span className="text-accent font-bold">•</span>
                <span>Scatter plot demonstrates tsunami's reach: significant waves traveled over 3000 km</span>
              </li>
            </ul>
          </Card>
        </div>
      </div>
    </main>
  )
}
